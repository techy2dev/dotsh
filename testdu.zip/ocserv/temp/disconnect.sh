#!/bin/bash

USERNAME=$1
PASS=$2

#Database Credentials#
HOST=''
USER=''
PASSWORD=''
DB='' 
PORT='3306'
#Database Credentials#

echo $PASS;
if [ "$PASS" = "Stop" ] ; then
mysql -u $USER -p$PASSWORD -D $DB -h $HOST -sN -e "UPDATE vpns SET online=0 WHERE username='$USERNAME'"
sleep 3
data=$(curl -sb -X POST  -F "disconnect=true" -F "user=$USERNAME" -F "pass=$PASS" "")
echo "disconnected">'/temp/ss.txt'
else
echo $PASS>'/temp/ss.txt'
fi	

