#!/bin/bash
USERNAME=$1
PASS=$2

data=$(curl -sb -x POST  -F "username=$USERNAME" -F "password=$PASS" "http://bslcard.fun/login/authe.php")
echo $data


