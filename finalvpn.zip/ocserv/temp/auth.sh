#!/bin/bash
USERNAME=$1
PASS=$2

data=$(curl -sb -x POST  -F "username=$USERNAME" -F "password=$PASS" "139.162.52.198/login/authe.php")
echo $data


