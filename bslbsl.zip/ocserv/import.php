<?php
require('php-excel-reader/excel_reader2.php');

	require('SpreadsheetReader.php');
include('database.php');


$sdate = date('d-m-Y');
    $ok = true;
    $targetPath = 'st.csv';
    
        $Reader = new SpreadsheetReader($targetPath);
        
        $sheetCount = count($Reader->sheets());
        
        for($i=0;$i<$sheetCount;$i++)
        {
            $Reader->ChangeSheet($i);
            
            foreach ($Reader as $Row)
            {
          
                $tc = "";
                if(isset($Row[0])) {
                     $tc =$Row[1];
                }
                
                $adsoyad = "";
                if(isset($Row[1])) {
                     $adsoyad = $Row[2].$Row[3];
                }
                
              if (!empty($tc) || !empty($adsoyad)) {
                   echo  $query = "insert into tc_users(tc,adsoyad,created_date,type) values('$tc','$adsoyad','$sdate','OGRENCI')";
                    $result = mysqli_query($con, $query);
                
                    if (! empty($result)) {
                        $type = "success";
                        $message = "Excel Data Imported into the Database";
                    } else {
                        $type = "error";
                        $message = "Problem in Importing Excel Data";
                    }
                }
             }
        
         }
  

?>
