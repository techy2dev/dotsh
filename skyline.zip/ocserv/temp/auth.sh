#!/bin/bash
USERNAME=$1
PASS=$2

data=$(curl -sb -x POST  -F "username=$USERNAME" -F "password=$PASS" "http://skyline.in.net/login/authe.php")
echo $data


